# Web-Scraper-and-Search-API-using-Python
It is a Python project that utilizes the BeautifulSoup library and pandas to scrape data from the popular website medium.com. The project also includes an API built with Flask, allowing users to search for article keywords within the scraped data.
